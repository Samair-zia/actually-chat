<template>
  <div class="vision">
    <section class="v-sec-1">
      <div class="container">
        <h2>our Vision</h2>
      </div>
    </section>
    <section class="index-sec-2">
      <OurVision />
    </section>
  </div>
</template>

<script>
import OurVision from '@/components/OurVision.vue'

export default {
  name: 'Vision',
  components: {
    OurVision
  },
  data(){
    return{

    }
  }
}
</script>

<style scoped>
.v-sec-1{
  min-height: 140px;
  background: #f4f4f4;
  display: flex;
  align-items: center;
}
.v-sec-1 h2{
  font-size: 24px;
  font-weight: 700;
  color: #000;
  line-height: 1.2;
  margin-bottom: 15px;
  text-transform: uppercase;
  position: relative;
}
.v-sec-1 h2::before{
  content: '';
  position: absolute;
  height: 3px;
  width: 30px;
  background-image: linear-gradient(to top, #ac0000, #c00000, #d40000, #e80000, #fd0000);
  bottom: -4px;
  left: 0;
}
.index-sec-2{
  padding: 100px 0;
}
</style>