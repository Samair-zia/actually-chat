<template>
  <div class="team">
    <section class="t-sec-1">
      <div class="container">
        <h2>Our Team</h2>
      </div>
    </section>
    <OurTeam />
  </div>
</template>

<script>
import OurTeam from '@/components/OurTeam.vue'


export default {
  name: 'Team',
  components:{
    OurTeam
  },
  data(){
    return{
      members: [
        { 
          name: `Sara Wu`,
          designation: `Ph.D, CEO and Founder`,
          desc: `Sara, trained as a medicinal and pharmaceutical chemist, has been working in the pharmaceutical industry for more than 20 years on drug product formulation development and manufacturing. In her career in pharmaceutical development, Sara was involved or made significant contributions to the development of a couple of cancer drugs that were approved and are being used to treat patients. She also worked on other drugs’ development that maybe approved in the future. <br><br> With a strong passion and vision, Sara truly believes Actually Health Chat will benefit people around the world in helping them to make better decisions related to their health care.`,
          img: require('@/assets/images/team-img-1.jpg') 
        },
        { 
          name: `Prabhavathi Fernandes`,
          designation: `Ph.D. Co-Founder and Chief Scientific Advisor`,
          desc: `Prabha has over 40 years of experience in the health care field. She has held leadership positions in Major pharmaceutical companies in the U.S. and has founded and led biotechnology companies. During these years she has developed several pharmaceutical products that are currently marketed. She is currently the Chair of the National Biodefense Science Board (NBSB), and Chair of the Global Research and Development Partnership (GARDP, Geneva) and Member of NIH Accelerating COVID-19 Therapeutic Interventions and Vaccines (ACTIV). She is a Director of three Public and Private Biotechnology companies in the US and Europe. <br><br> Health Care and staying well has been a passion for her over her lifetime. She looks forward to learning and sharing knowledge and experiences in Actually Health Chat to contribute to the health and well being of the community.`, 
          img: require('@/assets/images/team-img-2.jpg') 
        },
        { 
          name: `Klaus Larres`,
          designation: `Ph.D, Advisor for Global Public Relations`,
          desc: `Prof. Larres is the <b>Richard M. Krasno Distinguished Professor of History and International Affairs</b> at the University of North Carolina in Chapel Hill, NC. Prof. Larres directs the <b>Krasno Global Affairs and Business Council</b> and is in charge of the <b>Krasno Events Series</b>.  Prof. Larres focuses on the foreign, economic and security policies of the U.S., China, Germany and the EU.  He has published widely on all of the above research themes. He frequently gives interviews to the global media and is often consulted by media organizations & think tanks and international businesses.<br><br> He has recently served as a <b>Counselor and Senior Policy Adviser</b> at the German Embassy in Beijing, China. He is a Distinguished Visiting Professor at the <b>Indian Institute of Technology</b> in Mumbai, India. He has also been asked to serve on the "International Board" of the <b>Bundeskanzler-Willy-Brandt-Stiftung</b> in Berlin.`, 
          img: require('@/assets/images/team-img-3.jpg'),
        }
      ]
    }
  }
}
</script>

<style scoped>
.t-sec-1{
  min-height: 140px;
  background: #f4f4f4;
  display: flex;
  align-items: center;
}
.t-sec-1 h2{
  font-size: 24px;
  font-weight: 700;
  color: #000;
  line-height: 1.2;
  margin-bottom: 15px;
  text-transform: uppercase;
  position: relative;
}
.t-sec-1 h2::before{
  content: '';
  position: absolute;
  height: 3px;
  width: 30px;
  background-image: linear-gradient(to top, #ac0000, #c00000, #d40000, #e80000, #fd0000);
  bottom: -4px;
  left: 0;
}
</style>