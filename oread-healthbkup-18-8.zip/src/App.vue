<template>
  <div id="app">
    <Header />
      <router-view/>
    <Footer />
  </div>
</template>

<script>
import Header from '@/components/layout/Header.vue'
import Footer from '@/components/layout/Footer.vue'

export default {
  components: {
    Header,
    Footer
  },
  data(){
    return{
      // nonHeaderPages: ['views.login'],
      // nonFooterPages: ['views.login'],
    }
  },
  computed: {

  }
}
</script>