<template>
  <div class="categories">
    <Category />
  </div>
</template>

<script>
import Category from '@/components/Category.vue'

export default {
  name: 'Categories',
  components: {
    Category
  },
  data(){
    return{

    }
  }
}
</script>

<style scoped>

</style>