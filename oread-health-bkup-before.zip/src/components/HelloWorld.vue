<template>
  <div class="hello">
   <button class="btn-primary btn">dfjhs</button>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  }
}
</script>

<style scoped>

</style>
